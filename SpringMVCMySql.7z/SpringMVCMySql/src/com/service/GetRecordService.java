package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.GetRecord;
import com.model.Users;

@Service
public class GetRecordService {

	@Autowired
	private GetRecord getRecord;
	
	public List<Users> getData(){
		
		return getRecord.listUsers();
	}
}
