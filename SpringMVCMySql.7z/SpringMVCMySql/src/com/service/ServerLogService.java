package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ServerLogDAO;
import com.model.ServerLogs;

@Service
public class ServerLogService {
@Autowired
ServerLogDAO serverLogDAO;
	public List<ServerLogs> getServerLog(){
		
		return  serverLogDAO.getServerLogs();
	}
}
