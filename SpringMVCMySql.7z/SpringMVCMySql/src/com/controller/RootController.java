package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.model.ServerLogs;
import com.model.Users;
import com.service.GetRecordService;
import com.service.ServerLogService;

@Controller

public class RootController {

   @Autowired
   GetRecordService getrecordService;
   @Autowired
   ServerLogService serverLogService;
   
	@RequestMapping("/")
	public ModelAndView getIndexPage(HttpServletRequest request, HttpServletResponse response){
		System.out.println("hello");
		ModelAndView mav=new ModelAndView();
		mav.setViewName("index");
		System.out.println(request.getServletPath());
		return mav;
	}
	
	
	@RequestMapping("/getWelcome")
	public ModelAndView getWelcomePage(HttpServletRequest request, HttpServletResponse response){
		System.out.println("hello");
		ModelAndView mav=new ModelAndView();
		mav.setViewName("welcome");
		List<Users> al=getrecordService.getData();
		
		for(Users u: al){
			System.out.println(u.toString());
		}
		
		
     List<ServerLogs> al1=serverLogService.getServerLog();
		
		for(ServerLogs serverLogs: al1){
			System.out.println(serverLogs.toString());
		}
		
		
		
		System.out.println(request.getServletPath());
		return mav;
	}
}
