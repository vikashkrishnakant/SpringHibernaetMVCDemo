package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Users;

@Repository
public class GetRecord {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<Users> listUsers() {
		Session session = sessionFactory.openSession();
		String userName="admin";
		String userPassword="admin";
		SQLQuery q = session.createSQLQuery("select ID, USERNAME,CAST(AES_DECRYPT(PASSWORD,'password') as char(20))AS PASSWORD,USERTYPE,ACCESSRIGHT,LOGINSTATUS from users where USERNAME='" + userName + "' and PASSWORD=AES_ENCRYPT('"
				+ userPassword + "','password') and ACCESSRIGHT='S' ;");
		q.addEntity(Users.class);

		List<Users> userList = q.list();
		return userList;
	   }
	
}
