package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class has attributes that is  intended  to store action performed by user with date and time.<br>
 * <br>
 * <i>The action may include</i><br>
 * ---Satrt, Stop and Reset DMD(MPU).<br>
 * ---Change the password.<br>
 * ---Update of MPU I/O path.<br>
 * ---Add/Update the client. <br>
 * etc.....
 * @author Vikash
 *
 */

@Entity
@Table(name = "server_logs" , schema="sat_db_new")
public class ServerLogs implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column
	String date;
	@Column
	String time;
	@Column
	String action;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "ServerLog [id=" + id + ", date=" + date + ", time=" + time + ", action=" + action + "]";
	}


}
