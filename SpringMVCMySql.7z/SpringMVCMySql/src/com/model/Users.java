package com.model;




import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name = "users", schema="sat_db_new",uniqueConstraints = @UniqueConstraint(columnNames = {"USERNAME","USERTYPE","ACCESSRIGHT"}))
public class Users implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	@GeneratedValue
	int ID;
	@Column
	String USERNAME = "";
	@Column
	String PASSWORD = "";
	@Column
	String USERTYPE = "";
	@Column
	String ACCESSRIGHT = "";
	@Column
	String LOGINSTATUS = "";

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getUSERNAME() {
		return USERNAME;
	}

	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}

	public String getPASSWORD() {
		return PASSWORD;
	}

	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}

	public String getUSERTYPE() {
		return USERTYPE;
	}

	public void setUSERTYPE(String uSERTYPE) {
		USERTYPE = uSERTYPE;
	}
	
	
	

	

	public String getACCESSRIGHT() {
		return ACCESSRIGHT;
	}

	public void setACCESSRIGHT(String aCCESSRIGHT) {
		ACCESSRIGHT = aCCESSRIGHT;
	}

	public String getLOGINSTATUS() {
		return LOGINSTATUS;
	}

	public void setLOGINSTATUS(String lOGINSTATUS) {
		LOGINSTATUS = lOGINSTATUS;
	}

	public static final String RESPONSE_STATE = "response-state";
	public static final String COLUMN_ID = "ID";
	public static final String COLUMN_USER_NAME = "USERNAME";
	public static final String COLUMN_PASSWORD = "PASSWORD";
	public static final String COLUMN_UserType = "USERTYPE";
	public static final String COLUMN_AccessRight = "ACCESSRIGHT";
	public static final String COLUMN_LoginStatus = "LOGINSTATUS";

	@Override
	public String toString() {
		return "Users [ID=" + ID + ", USERNAME=" + USERNAME + ", PASSWORD=" + PASSWORD + ", USERTYPE=" + USERTYPE
				+ ", ACCESSRIGHT=" + ACCESSRIGHT + ", LOGINSTATUS=" + LOGINSTATUS + "]";
	}
		
}
